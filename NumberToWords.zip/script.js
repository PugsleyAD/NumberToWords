// A string builder class, should be written in an independent JS file for a project, but since we only have one usage, put together is ok
class StringBuilder {
  constructor() {
    this.value = "";
  }

  append(str) {
    this.value += str;
    return this;
  }

  clear() {
    this.value = "";
    return this;
  }

  toString() {
    return this.value;
  }
}

function reset() {
  for (i = 1; i < 14; i++) {
    let id = String(i);
    const div = document.getElementById(id);
    div.textContent = "";
  }

  const numIn = document.getElementById("numberInput");

  numIn.value = "";
}

function convertToWords() {
  for (i = 1; i < 14; i++) {
    let id = String(i);
    const div = document.getElementById(id);
    div.textContent = "";
  }

  const numberInput = document.getElementById("numberInput");

  const regex = /^\d+(\.\d*)?$/;
  if (!regex.test(numberInput.value)) {
    alert("Please enter valid $ dollar amount!");
  }

  const numberStr = String(numberInput.value);

  const parts = numberStr.split(".");
  const integerStr = parts[0];
  let decimalStr = parts[1];

  const integerArray = Array.from(integerStr);

  if (decimalStr !== undefined) {
    const decimalArray = Array.from(decimalStr);
    if (decimalArray.length > 2) {
      alert("Input number has been rounded to 2 Decimal!");
    }
    if (
      decimalArray[0] === "9" &&
      decimalArray[1] === "9" &&
      decimalArray[2] >= 5
    ) {
      integerArray.push(String(Number(integerArray.pop()) + 1));
      decimalArray[0] = "0";
      decimalArray[1] = "0";
    } else if (decimalArray[2] >= 5) {
      decimalArray[1] = Number(decimalArray[1]) + 1;
    }
    decimalStr = decimalArray[0] + decimalArray[1];
  }

  let sectorArray = [];

  const topDigits = integerArray.length % 3;

  if (topDigits === 0) {
    for (i = 0; i < integerArray.length; i = i + 3) {
      let sector = integerArray[i] + integerArray[i + 1] + integerArray[i + 2];
      sectorArray.push(sector);
      sector = "";
    }
  }

  if (topDigits === 1) {
    sectorArray.push(integerArray[0]);
    for (i = 1; i < integerArray.length; i = i + 3) {
      let sector = integerArray[i] + integerArray[i + 1] + integerArray[i + 2];
      sectorArray.push(sector);
      sector = "";
    }
  }

  if (topDigits === 2) {
    sectorArray.push(integerArray[0] + integerArray[1]);
    for (i = 2; i < integerArray.length; i = i + 3) {
      let sector = integerArray[i] + integerArray[i + 1] + integerArray[i + 2];
      sectorArray.push(sector);
      sector = "";
    }
  }

  const wordsArray = bindingMagnitude(sectorArray);

  const lines = sectorArray.length;

  // Check if either parts === 1 or 0
  const isI = String(sectorArray[lines - 1]).trim();
  const isD = String(Number(decimalStr)).trim();

  if (isNaN(isD)) {
    for (i = 1; i <= lines; i++) {
      if (lines === 1 && (isI === "1" || isI === "0")) {
        const div = document.getElementById("1");
        div.textContent = wordsArray + " DOLLAR ";
      } else if (lines === 1 && isI !== "1") {
        const div = document.getElementById("1");
        div.textContent = wordsArray + " DOLLARS ";
      } else {
        if (i === lines) {
          let id = String(i);
          const div = document.getElementById(id);
          div.textContent = wordsArray[i - 1] + " DOLLARS ";
        } else {
          let id = String(i);
          const div = document.getElementById(id);
          div.textContent = wordsArray[i - 1];
        }
      }
    }
  } else {
    for (i = 1; i <= lines; i++) {
      if (lines === 1 && (isI === "1" || isI === "0")) {
        const div = document.getElementById("1");
        div.textContent =
          wordsArray +
          " DOLLAR AND " +
          convertTwoDigits(decimalStr) +
          (isD === "1" || isD === "0" ? " CENT" : " CENTS");
      } else if (lines === 1 && isI !== "1") {
        const div = document.getElementById("1");
        div.textContent =
          wordsArray +
          " DOLLARS AND " +
          convertTwoDigits(decimalStr) +
          (isD === "1" || isD === "0" ? " CENT" : " CENTS");
      } else {
        if (i === lines) {
          let id = String(i);
          const div = document.getElementById(id);
          div.textContent =
            wordsArray[i - 1] +
            " DOLLARS AND " +
            convertTwoDigits(decimalStr) +
            (isD === "1" || isD === "0" ? " CENT" : " CENTS");
        } else {
          let id = String(i);
          const div = document.getElementById(id);
          div.textContent = wordsArray[i - 1];
        }
      }
    }
  }
}

// Convert a 2 digits number
function convertTwoDigits(numStr) {
  const numberWords = [
    "ZERO",
    "ONE",
    "TWO",
    "THREE",
    "FOUR",
    "FIVE",
    "SIX",
    "SEVEN",
    "EIGHT",
    "NINE",
    "TEN",
    "ELEVEN",
    "TWELVE",
    "THIRTEEN",
    "FOURTEEN",
    "FIFTEEN",
    "SIXTEEN",
    "SEVENTEEN",
    "EIGHTEEN",
    "NINETEEN",
    "TWENTY",
    "THIRTY",
    "FORTY",
    "FIFTY",
    "SIXTY",
    "SEVENTY",
    "EIGHTY",
    "NINETY",
  ];

  num = Number(numStr);
  if (num < 20) {
    return numberWords[num];
  }

  const tens = Math.floor(num / 10);
  const ones = num % 10;

  const words =
    numberWords[tens + 18] + (ones === 0 ? "" : "-" + numberWords[ones]);
  return words;
}

// Convert a 3 digits number
function convertThreeDigits(numStr) {
  const numberWords = [
    "",
    "ONE",
    "TWO",
    "THREE",
    "FOUR",
    "FIVE",
    "SIX",
    "SEVEN",
    "EIGHT",
    "NINE",
  ];

  const fromArray = Array.from(numStr);
  if (fromArray.length < 3) {
    return convertTwoDigits(numStr);
  }

  num = Number(numStr);
  const hundreds = Math.floor(num / 100);
  const tens = Math.floor(num % 100);

  const words =
    numberWords[hundreds] +
    " " +
    (String(Number(numStr)).length === 3 ? "HUNDRED" : "") +
    " " +
    convertTwoDigits(tens);

  return words;
}

function bindingMagnitude(numStrArray) {
  const magnitude = [
    "",
    "THOUSAND",
    "MILLION",
    "BILLION",
    "TRILLION",
    "QUADRILLION",
    "QUINTILLION",
    "SEXTILLION",
    "SEPTILLION",
    "QCTILLION",
    "NONILLION",
    "DECILLION",
    "UNDECILLION",
  ];

  if (numStrArray.length < 2) {
    return convertThreeDigits(numStrArray[0]);
  }

  // Calculate number of sets (of 3 digits)
  const magCount = numStrArray.length;

  let wordsArray = [];
  for (i = 0; i < magCount; i++) {
    sector =
      convertThreeDigits(numStrArray[i]) + " " + magnitude[magCount - i - 1];
    wordsArray.push(sector);
    sector = "";
  }

  return wordsArray;
}
